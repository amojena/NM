# include any code you need for your assignment in this file or in auxiliary
# files that can be imported here.

# 8 (a)
# implement an algorithm that given a graph G, set of adopters S,
# and a threshold q performs BRD where the adopters S never change.
def contagion_brd(G, S, q):
    return -1


