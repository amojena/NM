# include any code you need for your assignment in this file or in auxiliary
# files that can be imported here.

# 9 (a)
# implement an algorithm that computes the maximum flow in a graph G
# Note: you may represent the graph, source, sink, and edge capacities
# however you want. You may also change the inputs to the function below.
def max_flow(G, s, t, c):
    return -1

# 9 (c)
# implement an algorithm that computes a maximum matching in a bipartite graph G
# Note: you may represent the bipartite graph however you want
def max_matching(G):
    return M # a matching


    

